# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os

addon = xbmcaddon.Addon()
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))

def installer_keymap():

    # Fichier source dans l’addon
    source = os.path.join(addon_path, "resources", "keyboard.xml")

    # Destination dans userdata/keymaps
    target = xbmcvfs.translatePath("special://profile/keymaps/keyboard.xml")

    # Création du dossier keymaps si nécessaire
    dossier = os.path.dirname(target)
    if not xbmcvfs.exists(dossier):
        xbmcvfs.mkdirs(dossier)

    # Lecture du fichier source
    try:
        with xbmcvfs.File(source, "r") as f:
            contenu = f.read()
    except Exception as e:
        xbmcgui.Dialog().notification("❌ Erreur lecture", str(e), xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    # Écriture du fichier cible (compatible Android 12)
    try:
        with xbmcvfs.File(target, "w") as f:
            f.write(contenu)
    except Exception as e:
        xbmcgui.Dialog().notification("❌ Erreur écriture", str(e), xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    # Reload des keymaps
    xbmc.executebuiltin("Action(reloadkeymaps)")

    xbmcgui.Dialog().notification("✔ Keymap installé", "keyboard.xml injecté avec succès", xbmcgui.NOTIFICATION_INFO, 3000)


if __name__ == "__main__":
    installer_keymap()