# coding: utf-8
from __future__ import print_function, unicode_literals

import binascii
import collections
import warnings
import requests
import time
import os
import sys
import subprocess
import json
from urllib.parse import quote, unquote
from bs4 import BeautifulSoup
import re
import shutil
import random
import re
import hashlib
import base64
import json
import io
import sqlite3
from util import *
import widget

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import threading
import xml.etree.ElementTree as ET
import player

ADDON = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
KEYTMDB = ADDON.getSetting("apikey")
KEYALLDEB = ADDON.getSetting("keyalldebrid")
KEYREALDEB = ADDON.getSetting("keyrealdebrid")
HANDLE = int(sys.argv[1])
BDYGG = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/torrents.db')
CHEMIN = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/')
NBMEDIA = 50
from medias import Media, TMDB

def _detect(_):
    warnings.warn("No chardet module installed, encoding will be utf-8")
    return {"encoding": "utf-8", "confidence": 1}


__all__ = [
    "InvalidTorrentDataException",
    "BEncoder",
    "BDecoder",
]


def detect(content):
    return _detect(content)["encoding"]


class InvalidTorrentDataException(Exception):
    def __init__(self, pos, msg=None):
        msg = msg or "Invalid torrent format when read at pos {pos}"
        msg = msg.format(pos=pos)
        super(InvalidTorrentDataException, self).__init__(msg)


class __EndCls(object):
    pass


_END = __EndCls()


def _check_hash_field_params(name, value):
    return (
        isinstance(name, str)
        and isinstance(value, tuple)
        and len(value) == 2
        and isinstance(value[0], int)
        and isinstance(value[1], bool)
    )


class BDecoder(object):

    TYPE_LIST = "list"
    TYPE_DICT = "dict"
    TYPE_INT = "int"
    TYPE_STRING = "string"
    TYPE_END = "end"

    LIST_INDICATOR = b"l"
    DICT_INDICATOR = b"d"
    INT_INDICATOR = b"i"
    END_INDICATOR = b"e"
    STRING_INDICATOR = b""
    STRING_DELIMITER = b":"

    TYPES = [
        (TYPE_LIST, LIST_INDICATOR),
        (TYPE_DICT, DICT_INDICATOR),
        (TYPE_INT, INT_INDICATOR),
        (TYPE_END, END_INDICATOR),
        (TYPE_STRING, STRING_INDICATOR),
    ]

    # see https://docs.python.org/3/library/codecs.html#error-handlers
    # for other usable error handler string
    ERROR_HANDLER_USEBYTES = "usebytes"

    def __init__(
        self,
        data,
        use_ordered_dict=False,
        encoding="utf-8",
        errors="strict",
        hash_fields=None,
        hash_raw=False,
    ):
        """
        :param bytes|file data: bytes or a **binary** file-like object to parse,
          which means need 'b' mode when use built-in open function
        :param bool use_ordered_dict: Use collections.OrderedDict as dict
          container default False, which mean use built-in dict
        :param str encoding: file content encoding, default utf-8, use 'auto'
          to enable charset auto detection (need 'chardet' package installed)
        :param str errors: how to deal with encoding error when try to parse
          string from content with ``encoding``.
          see https://docs.python.org/3/library/codecs.html#error-handlers
          for usable error handler string.
          in particular, you can use "usebytes" to use "strict" decode mode
          and let it return raw bytes if error happened.
        :param Dict[str, Tuple[int, bool]] hash_fields: extra fields should
          be treated as hash value. dict key is the field name, value is a
          two-element tuple of (hash_block_length, as_a_list).
          See :any:`hash_field` for detail
        """
        if isinstance(data, bytes):
            data = io.BytesIO(data)
        elif getattr(data, "read") is not None and getattr(data, "seek") is not None:
            pass
        else:
            raise ValueError("Parameter data must be bytes or file like object")

        self._pos = 0
        self._encoding = encoding
        self._content = data
        self._use_ordered_dict = use_ordered_dict
        self._error_handler = errors
        self._error_use_bytes = False
        if self._error_handler == BDecoder.ERROR_HANDLER_USEBYTES:
            self._error_handler = "strict"
            self._error_use_bytes = True

        self._hash_fields = {}
        if hash_fields is not None:
            for k, v in hash_fields.items():
                if _check_hash_field_params(k, v):
                    self._hash_fields[k] = v
                else:
                    raise ValueError(
                        "Invalid hash field parameter, it should be type of "
                        "Dict[str, Tuple[int, bool]]"
                    )
        self._hash_raw = bool(hash_raw)

    def hash_field(self, name, block_length=20, need_list=False):
        """
        Let field with the `name` to be treated as hash value, don't decode it
        as a string.

        :param str name: field name
        :param int block_length: hash block length for split
        :param bool need_list:  if True, when the field only has one block(
          or even empty) its parse result will be a one-element list(
          or empty list); If False, will be a string in 0 or 1 block condition
        :return: return self, so you can chained call
        """
        v = (block_length, need_list)
        if _check_hash_field_params(name, v):
            self._hash_fields[name] = v
        else:
            raise ValueError("Invalid hash field parameter")
        return self

    def decode(self):
        """
        :rtype: dict|list|int|str|unicode|bytes
        :raise: :any:`InvalidTorrentDataException` when parse failed or error
          happened when decode string using specified encoding
        """
        self._restart()
        data = self._next_element()

        try:
            c = self._read_byte(1, True)
            raise InvalidTorrentDataException(
                0, "Expect EOF, but get [{}] at pos {}".format(c, self._pos)
            )
        except EOFError:  # expect EOF
            pass

        return data

    def _read_byte(self, count=1, raise_eof=False):
        assert count >= 0
        gotten = self._content.read(count)
        if count != 0 and len(gotten) == 0:
            if raise_eof:
                raise EOFError()
            raise InvalidTorrentDataException(
                self._pos, "Unexpected EOF when reading torrent file"
            )
        self._pos += count
        return gotten

    def _seek_back(self, count):
        self._content.seek(-count, 1)
        self._pos = self._pos - count

    def _restart(self):
        self._content.seek(0, 0)
        self._pos = 0

    def _dict_items_generator(self):
        while True:
            k = self._next_element()
            if k is _END:
                return
            if not isinstance(k, str) and not isinstance(k, bytes):
                raise InvalidTorrentDataException(
                    self._pos, "Type of dict key can't be " + type(k).__name__
                )
            if k in self._hash_fields:
                v = self._next_hash(*self._hash_fields[k])
            else:
                v = self._next_element(k)
            if k == "encoding":
                self._encoding = v
            yield k, v

    def _next_dict(self):
        data = collections.OrderedDict() if self._use_ordered_dict else dict()
        for key, element in self._dict_items_generator():
            data[key] = element
        return data

    def _list_items_generator(self):
        while True:
            element = self._next_element()
            if element is _END:
                return
            yield element

    def _next_list(self):
        return [element for element in self._list_items_generator()]

    def _next_int(self, end=END_INDICATOR):
        value = 0
        char = self._read_byte(1)
        neg = False
        while char != end:
            if not neg and char == b"-":
                neg = True
            elif not b"0" <= char <= b"9":
                raise InvalidTorrentDataException(self._pos - 1)
            else:
                value = value * 10 + int(char) - int(b"0")
            char = self._read_byte(1)
        return -value if neg else value

    def _next_string(self, need_decode=True, field=None):
        length = self._next_int(self.STRING_DELIMITER)
        raw = self._read_byte(length)
        if need_decode:
            encoding = self._encoding
            if encoding == "auto":
                self.encoding = encoding = detect(raw)
            try:
                try:
                    string = raw.decode(encoding, self._error_handler)
                except:
                    string = raw.decode("latin-1", self._error_handler)
            except UnicodeDecodeError as e:
                if self._error_use_bytes:
                    return raw
                else:
                    msg = [
                        "Fail to decode string at pos {pos} using encoding ",
                        e.encoding,
                    ]
                    if field:
                        msg.extend(
                            [
                                ' when parser field "',
                                field,
                                '"' ", maybe it is an hash field. ",
                                'You can use self.hash_field("',
                                field,
                                '") ',
                                "to let it be treated as hash value, ",
                                "so this error may disappear",
                            ]
                        )
                    raise InvalidTorrentDataException(
                        self._pos - length + e.start, "".join(msg)
                    )
            return string
        return raw

    def _next_hash(self, p_len, need_list):
        raw = self._next_string(need_decode=False)
        if len(raw) % p_len != 0:
            raise InvalidTorrentDataException(
                self._pos - len(raw), "Hash bit length not match at pos {pos}"
            )
        if self._hash_raw:
            return raw
        res = [
            binascii.hexlify(chunk).decode("ascii")
            for chunk in (raw[x : x + p_len] for x in range(0, len(raw), p_len))
        ]
        if len(res) == 0 and not need_list:
            return ""
        if len(res) == 1 and not need_list:
            return res[0]
        return res

    @staticmethod
    def _next_end():
        return _END

    def _next_type(self):
        for (element_type, indicator) in self.TYPES:
            indicator_length = len(indicator)
            char = self._read_byte(indicator_length)
            if indicator == char:
                return element_type
            self._seek_back(indicator_length)
        raise InvalidTorrentDataException(self._pos)

    def _type_to_func(self, t):
        return getattr(self, "_next_" + t)

    def _next_element(self, field=None):
        element_type = self._next_type()
        if element_type is BDecoder.TYPE_STRING and field is not None:
            element = self._type_to_func(element_type)(field=field)
        else:
            element = self._type_to_func(element_type)()
        return element


class BEncoder(object):

    TYPES = {
        (dict,): BDecoder.TYPE_DICT,
        (list,): BDecoder.TYPE_LIST,
        (int,): BDecoder.TYPE_INT,
        (str, bytes): BDecoder.TYPE_STRING,
    }

    def __init__(self, data, encoding="utf-8", hash_fields=None):
        """
        :param dict|list|int|str data: data will be encoded
        :param str encoding: string field output encoding
        :param List[str] hash_fields: see
          :any:`BDecoder.__init__`
        """
        self._data = data
        self._encoding = encoding
        self._hash_fields = []
        if hash_fields is not None:
            self._hash_fields = hash_fields

    def hash_field(self, name):
        """
        see :any:`BDecoder.hash_field`

        :param str name:
        :return: return self, so you can chained call
        """
        return self._hash_fields.append(str(name))

    def encode(self):
        """
        Encode to bytes

        :rtype: bytes
        """
        return b"".join(self._output_element(self._data))

    def encode_to_filelike(self):
        """
        Encode to a file-like(BytesIO) object

        :rtype: BytesIO
        """
        return io.BytesIO(self.encode())

    def _output_string(self, data):
        if isinstance(data, str):
            data = data.encode(self._encoding)
        yield str(len(data)).encode("ascii")
        yield BDecoder.STRING_DELIMITER
        yield data

    @staticmethod
    def _output_int(data):
        yield BDecoder.INT_INDICATOR
        yield str(data).encode("ascii")
        yield BDecoder.END_INDICATOR

    def _output_decode_hash(self, data):
        if isinstance(data, str):
            data = [data]
        result = []
        for hash_line in data:
            if not isinstance(hash_line, str):
                raise InvalidTorrentDataException(
                    None,
                    "Hash must be "
                    + str.__name__
                    + " not "
                    + type(hash_line).__name__,
                )
            if len(hash_line) % 2 != 0:
                raise InvalidTorrentDataException(
                    None,
                    "Hash("
                    + hash_line
                    + ") length("
                    + str(len(hash_line))
                    + ") is a not even number",
                )
            try:
                raw = binascii.unhexlify(hash_line)
            except binascii.Error as e:
                raise InvalidTorrentDataException(
                    None,
                    str(e),
                )
            result.append(raw)
        for x in self._output_string(b"".join(result)):
            yield x

    def _output_dict(self, data):
        yield BDecoder.DICT_INDICATOR
        for k, v in data.items():
            if not isinstance(k, str) and not isinstance(k, bytes):
                raise InvalidTorrentDataException(
                    None,
                    "Dict key must be "
                    + str.__name__
                    + " or "
                    + bytes.__name__,
                )
            for x in self._output_element(k):
                yield x
            if k in self._hash_fields:
                for x in self._output_decode_hash(v):
                    yield x
            else:
                for x in self._output_element(v):
                    yield x
        yield BDecoder.END_INDICATOR

    def _output_list(self, data):
        yield BDecoder.LIST_INDICATOR
        for v in data:
            for x in self._output_element(v):
                yield x
        yield BDecoder.END_INDICATOR

    def _type_to_func(self, t):
        return getattr(self, "_output_" + t)

    def _output_element(self, data):
        for types, t in self.TYPES.items():
            if isinstance(data, types):
                # noinspection PyCallingNonCallable
                return self._type_to_func(t)(data)
        raise InvalidTorrentDataException(
            None,
            "Invalid type for torrent file: " + type(data).__name__,
        )




class Alldebrid:

    def __init__(self, key):
        self.key = key.strip()
        self.urlBase = "https://api.alldebrid.com"

    @property
    def extractMagnets(self):
        url = self.urlBase + "/v4/magnet/status?agent=u2p&apikey=%s" %self.key
        tx = requests.get(url)
        dictInfo = json.loads(tx.text)
        tabLinks = []

        for media in dictInfo["data"]["magnets"]:
            if media["status"] == "Ready":
                for link in media["links"]:
                    if link["filename"][-4:] in [".mp4", ".mkv", ".avi", "dixw", ".mp3"]:
                        tabLinks.append((link["filename"], link["link"], media["id"], media["hash"]))
        dictId = {x[2]: (x[0], x[1], x[3])  for x in tabLinks}
        dictHash = {x[3]: (x[0], x[1], x[2])  for x in tabLinks}
        return tabLinks[::-1], dictId, dictHash

    @property
    def extractEnCours(self):
        url = self.urlBase + "/v4/magnet/status?agent=u2p&apikey=%s" %self.key
        tx = requests.get(url)
        dictInfo = json.loads(tx.text)
        tabEncours = []
        for media in dictInfo["data"]["magnets"]:
            if media["status"] == "Downloading":
                tabEncours.append(media["hash"])
        return tabEncours

    def extractListe(self, t="history"):
        #history , links
        url = self.urlBase + "/v4/user/%s?agent=u2p&apikey=%s" %(t, self.key)
        tx = requests.get(url)
        dictInfo = json.loads(tx.text)
        tabLinks = []
        for link in dictInfo["data"]["links"]:
            if link["filename"][-4:] in [".mp4", ".mkv", ".avi", "dixw", ".mp3"]:
                tabLinks.append((link["filename"], link["link"].replace("https://uptobox.com/", "")))
        return tabLinks

    def linkDownload(self, lien):
        dlLink = ""
        url1 = self.urlBase + "/v4/link/unlock?agent=u2p&apikey=%s&link=https://uptobox.com/%s" % (self.key , lien)
        req = requests.get(url1)
        dict_liens = req.json()
        try:
            if dict_liens["status"] == "success":
                dlLink = dict_liens['data']['link']
                statut = "success"
            else:
                statut = dict_liens["error"]["code"]
        except:
            dlLink = ""
            statut = "err"
        return dlLink, statut

    def uploadMagnet(self, magnet):
        url = self.urlBase + "/v4/magnet/upload?agent=u2p&apikey=%s&magnets[]=%s" %(self.key, magnet)
        req = requests.get(url)
        dictInfos = req.json()
        return dictInfos

    def testCash(self, hsh):
        if type(hsh) == str:
            test = "magnets[]={}".format(hsh)
        else:
            test = "&".join(["magnets[]={}".format(x) for x in hsh])
        #notice(test)
        url = self.urlBase + "/v4/magnet/instant?agent=myAppName&apikey={}&{}".format(self.key, test)
        req = requests.get(url)
        dictInfos = req.json()
        return dictInfos

    def extractMagnetsId(self, idt):
        #https://api.alldebrid.com/v4/magnet/upload?agent=myAppName&apikey=someValidApikeyYouGenerated&magnets[]=MAGNET
        url = self.urlBase + "/v4/magnet/status?agent=u2p&apikey={}&id={}".format(self.key, idt)
        req = requests.get(url)
        dictInfos = req.json()
        return dictInfos

    def deleteTorrent(self, idt):
        url = self.urlBase + "/v4/magnet/delete?agent=u2p&apikey={}&id={}".format(self.key, idt)
        req = requests.get(url)
        dictInfos = req.json()
        return dictInfos

    def uploadTorrent(self, torrents):
        if type(torrents) == str:
            files = [('files[]', open(torrents, 'rb'))]
        else:
            files = []
            for torrent in torrents:
                files.append(('files[]', open(torrent, 'rb')))
        r = requests.post(self.urlBase + '/v4/magnet/upload/file?agent=%s&apikey=%s' %("u2p", self.key), files=files)
        dictData = r.json()
        notice(dictData)

class RealDebrid:
    def __init__(self, key):
        self.key = key.strip()
        self.urlBase = "https://api.real-debrid.com/rest/1.0"

    def linkDownload(self, lien):
        headers = {'Authorization': 'Bearer %s' %self.key}
        data = {'link': lien, 'password':''}
        r = requests.post(self.urlBase + '/unrestrict/link', data=data, headers=headers)
        dictData = r.json()
        if 'error' in dictData.keys():
            link, status = "", 'err'
        else:
            link, status = dictData['download'], "ok"

        return link, status

    def cacheHash(self, hsh):
        if type(hsh) != str:
            hsh = "/".join(hsh)
        headers = {'Authorization': 'Bearer %s' %self.key}
        url = self.urlBase + "/torrents/instantAvailability/{}".format(hsh)
        r = requests.get(url, headers=headers)
        return r.json()

    def addMagnet(self, magnet):
        if "magnet" not in magnet:
            magnet = "magnet:?xt=urn:btih:" + magnet
        headers = {'Authorization': 'Bearer %s' %self.key}
        data = {'magnet': magnet,
            'host': 'real-debrid.com'}
        #notice(data)
        url = self.urlBase + "/torrents/addMagnet"
        r = requests.post(url, data=data, headers=headers)
        #notice(r.status_code)
        return r.json()

    def addTorrent(self, filepath, host='real-debrid.com'):
        headers = {'Authorization': 'Bearer %s' %self.key}
        data = {'host': host}
        url = self.urlBase + "/torrents/addTorrent"
        with open(filepath, 'rb') as file:
            r = requests.put(url, data=file, headers=headers, params=data)
        return r.json()

    def add_magnet(self, magnet, host=None):
            magnet_link = 'magnet:?xt=urn:btih:' + str(magnet)
            return self.rd.post('/torrents/addMagnet', magnet=magnet_link, host=host)

    def torrentInfos(self, idt):
        headers = {'Authorization': 'Bearer %s' %self.key}
        url = self.urlBase + "/torrents/info/{}".format(idt)
        r = requests.get(url, headers=headers)
        return r.json()

    def startTorrent(self, idt, num="all"):
        headers = {'Authorization': 'Bearer %s' %self.key}
        data = {'files': num}
        url = self.urlBase + "/torrents/selectFiles/{}".format(idt)
        r = requests.post(url, data=data, headers=headers)
        #notice(r.status_code)
        return r.status_code


    def getTorrents(self):
        headers = {'Authorization': 'Bearer %s' %self.key}
        url = self.urlBase + "/torrents"
        r = requests.get(url, headers=headers)
        return r.json()

    def getFiles(self, cash):
        #{'93e9c98617acfd532623a837f4a2977ea69d509a': {'rd': [{'1': {'filesize': 2723889008, 'filename': 'Oppenheimer.2023.MULTi.TRUEFRENCH.1080p.10bit.BluRay.6CH.x265.HEVC-Slay3R.mkv'}}]}}
        nums = []
        for hsh, files in cash.items():
            for k, file in files.items():
                for fichier in file:
                    for num, detail in fichier.items():
                        if detail["filename"][-3:].upper() in ["AVI", "MP4", "MKV", ".TS"]:
                            nums.append(str(num))
        return ",".join(nums)

    def deleteTorrent(self, idt):
        headers = {'Authorization': 'Bearer %s' %self.key}
        url = self.urlBase + "/torrents/delete/{}".format(idt)
        #notice(url)
        r = requests.delete(url, headers=headers)
        #notice(r.status_code)
        return r.status_code

class Torrent:
    def make_magnet_from_file(self, file) :
        with open(file, "rb") as f:
            tx = f.read()

        # methode b
        for enc in ["latin-1", "UTF-8"]:
            #notice(enc)
            try:
                metadata = BDecoder(tx, use_ordered_dict=False, encoding=enc, errors="strict", hash_fields=None, hash_raw=False).decode()
                hashcontents = BEncoder(metadata["info"], encoding=enc, hash_fields=None).encode()
                break
            except Exception as e:
                notice(e)
        digest = hashlib.sha1(hashcontents).digest()
        b32hash = base64.b32encode(digest).decode()
        infoHash = base64.b16encode(digest).decode()
        try:
            longueur = str(metadata['info']['length'])
        except:
            longueur =  str(metadata['info']['piece length'])
        magnet =  'magnet:?'\
                 + 'xt=urn:btih:' + b32hash\
                 + '&dn=' + metadata['info']['name']\
                 + '&tr=' + quote(metadata['announce'])\
                 + '&xl=' + longueur
        title = metadata['info']['name']
        return title, infoHash, magnet

    def decodeURL(self, s):
        url = base64.urlsafe_b64decode(s + '=' * (4 - len(s) % 4))
        return url.decode("utf-8")


    def extractHashBrut(self, file):
        with open(file, "rb") as f:
            tx = f.read()

        # methode brut
        pos = tx.decode("latin-1").find(":info")
        pos2 = tx.decode("latin-1").find("3:uid")
        if pos2 > 0:
            fin = pos2
        else:
            fin = -1

        hashcontents1 = tx[pos + 5: fin]
        digest = hashlib.sha1(hashcontents1).digest()
        b32hash = base64.b32encode(digest).decode()
        infoHash1 = base64.b16encode(digest).decode()
        return infoHash1

    def recupTorrentsRss(self, url, rep, repTorrent="../torrent"):
        try:
            nbGet = 0
            try:
                os.mkdir(os.path.join(repTorrent, rep))
            except: pass
            try:
                os.mkdir(os.path.join(repTorrent, rep, "fait"))
            except: pass

            tabTorrent = [files for root, dirs, files in os.walk(repTorrent)]
            tabTorrent = [x for y in tabTorrent for x in y]
            tabTorrent = [x for x in tabTorrent if "torrent" in x]

            r = requests.get(url, timeout=5, verify=True)
            tree = ET.fromstring(r.text)
            channel = tree.find('channel')
            items = channel.findall("item")
            for item in items:
                #try:
                #    category = item.find("category").text
                #except: category = ""
                try:
                    url = item.find("enclosure").get("url")
                except:
                    url = item.find("link").text
                title = item.find("title").text

                description =  item.find("description").text
                hshF = re.search(r"(\w{40})\.", description)
                if hshF:
                    urlsite = "/".join(url.split("/")[:3])
                    linkTorrent = urlsite + "/get_torrent/{}".format(hshF.group(1).upper())
                    #print(linkTorrent)
                else:
                    linkTorrent = None
                nameFile = '%s.torrent' %title.split("(S:")[0].strip()[:84]
                tab_remp = [r'''\\|/|:|\*|\?|<|>|\||"|,''', ' ']
                nameFile = re.sub(tab_remp[0], tab_remp[1], nameFile)
                nameFile = nameFile.strip()
                test = 0
                if nameFile not in tabTorrent:
                    #notice(nameFile)
                    while test < 10:
                        if linkTorrent:
                            url = linkTorrent
                        r = requests.get(url, allow_redirects=True, verify=True, timeout=2)
                        if r.status_code == 200:
                            open(os.path.join(repTorrent, rep, nameFile), 'wb').write(r.content)
                            nbGet += 1
                            time.sleep(random.randint(1, 5) / 10)
                            break
                    test += 1
                    time.sleep(1)


            return rep, nbGet
        except Exception as e:
            notice(e)
            return "%s => err" %(url), 0


class BDygg:
    def __init__(self, database):
        self.database = database
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS reps(
                id INTEGER PRIMARY KEY,
                rep TEXT,
                title TEXT,
                link TEXT,
                magnet TEXT,
                torrent TEXT,
                actif INTEGER default 1,
                UNIQUE (link))
              """)
        cur.execute("""CREATE TABLE IF NOT EXISTS rss(
                rep TEXT,
                link TEXT,
                UNIQUE (rep, link))
              """)
        cnx.commit()
        cur.close()
        cnx.close()

    def insertRss(self, tab):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.executemany("INSERT INTO rss (rep, link) VALUES (?, ?)", tab)
        cnx.commit()
        cur.close()
        cnx.close()

    def delRss(self):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("DELETE FROM rss")
        cnx.commit()
        cur.close()
        cnx.close()

    def getRss(self):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        sql = "SELECT rep, link FROM rss"
        cur.execute(sql)
        liste = cur.fetchall()
        cur.close()
        cnx.close()
        return liste

    def getMagnet(self, hsh):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        sql = "SELECT magnet FROM reps WHERE link=?"
        cur.execute(sql, (hsh,))
        liste = cur.fetchone()
        cur.close()
        cnx.close()
        return liste[0]

    def insertTorrent(self, title, hsh, typM, magnet, torrent):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("REPLACE INTO reps (rep, title, link, magnet, torrent) VALUES (?, ?, ?, ?, ?)", (typM, title.replace("'", "''"), hsh, magnet, torrent,))
        cnx.commit()
        cur.close()
        cnx.close()

    def recupListe(self, typM, nb, offset):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        sql = "SELECT title, link FROM reps WHERE rep='{}' ORDER BY id DESC LIMIT {} OFFSET {}".format(typM, nb, offset)
        cur.execute(sql)
        liste = cur.fetchall()
        cur.close()
        cnx.close()
        return liste

    def getTorrent(self, torrent):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        sql = "SELECT torrent FROM reps WHERE torrent=?"
        cur.execute(sql, (torrent,))
        liste = cur.fetchall()
        cur.close()
        cnx.close()
        if liste:
            return True
        else:
            return False


class RenameMedia:

    def extractInfo(self, name, typM="serie"):
        name = unquote(name)
        if typM == "movie":
            motif = r"""(?P<film>.*)([_\.\(\[ -]{1})(?P<an>19\d\d|20\d\d)([_\.\)\] -]{1})(.*)"""
            try:
                r = re.match(motif, name)
                title = r.group('film')
            except:
                title = name[:-4]
            try:
                year = int(r.group('an').replace('.', ''))
            except:
                year = 0
            if r:
                nameFinal = self.correctNom(title)
                nameFinal = nameFinal.replace(str(year), "")
            else:
                nameFinal = name

            return [nameFinal, year]

        else:
            for m in ["_", " ", "[", "]", "-", "(", ")", "{", "}", ",", ";"]:
                name = name.replace(m, ".")
            tab_remp = [r'''-|_|iNTERNAL|MULTi|2160p|4k|1080p|720p|480p|WEB-DL|hdlight|WEB|AC3|aac|hdtv|hevc|\d\dbit|subs?\.|vos?t?|x\.?265|STEGNER|x\.?264|FRENCH|DD\+.5.1|DD\+| |SR\.?71|h264|h265|1920x1080''', '.']
            name = re.sub(tab_remp[0], tab_remp[1], name, flags=re.I)
            name = re.sub(r"\.{2,}", ".", name)
            masque = r'(?P<year>19\d\d|20\d\d)'
            r = re.search(masque, name)
            if r:
                year = r.group("year")
            else:
                year = 0

            if year:
                name = name.replace(year, "")
            nameFinal, saison, numEpisode = name, "", ""
            masques = [r'[sS](?P<saison>\d?\d)\.?(ep?)\.?(?P<episode>\d\d\d\d)\.',
                       r'[sS](?P<saison>\d?\d)\.?(ep?)\.?(?P<episode>\d?\d?\d)\.',
                       r'(?P<saison>\d?\d)\.?(x)\.?(?P<episode>\d?\d?\d)\.',
                       r'(\.)(ep?)\.?(?P<episode>\d?\d?\d)\.',
                       r'(part)\.?(?P<episode>\d)\.',
                       r'(dvd)\.?(?P<episode>\d)\.',
                       r'(Saison)\.?(?P<saison>\d?\d)\.?(Episode|e)\.?(?P<episode>\d?\d)\.',
                       r'[sS](?P<saison>\d?\d)\.?(ep?)\.?(?P<episode>\d?\d?\d)',
                       r'(ep?)\.?(?P<episode>[0-1][0-8]\d\d)\.',
                       r'(ep?)\.?(?P<episode>\d?\d?\d)',
                       r'(?P<episode>[0-1][0-8]\d\d)',
                       r'\.[sS](?P<saison>\d\d)\.'
                       ]

            for motif in masques:
                r = re.search(motif, name, re.I)
                if r:
                    try:
                        try:
                            saison = "%s" %r.group("saison").zfill(2)
                            valid = 1
                        except:
                            saison = "01"
                        try:
                            numEpisode = "S%sE%s" %(saison, r.group("episode").zfill(4))
                        except:
                            numEpisode = ""

                    except Exception as e:
                        print(e)
                    nameFinal = name[:r.start()]
                    break
            #notice("%s %s %s %s" %(nameFinal, saison, numEpisode, year))
            if r:
                return [nameFinal, saison, numEpisode, year]
            else:
                return [name, "", "", year]

    def correctNom(self, title, tabRep=[]):
        title = unquote(title, encoding='latin-1', errors='replace')
        title = unicodedata.normalize('NFD', title).encode('ascii','ignore').decode("latin-1")
        tab_remp = [r'''\(.*\)|_|\[.*\]| FR |Episode| {2,}''', ' ']
        title = re.sub(tab_remp[0], tab_remp[1], title, flags=re.I)
        for repl in tabRep:
                title = title.replace(repl[0], repl[1])
        title = re.sub(r"^ \.?", "", title, flags=re.I)
        title = re.sub(r"\.{2,}", ".", title, flags=re.I)
        title = re.sub(r" {2,}", " ", title, flags=re.I)
        return title

    def nettNom(self, title, tabRep=[]):
        title = unquote(title, encoding='latin-1', errors='replace')
        title = unicodedata.normalize('NFD', title).encode('ascii','ignore').decode("latin-1")
        for repl in tabRep:
            title = title.replace(repl[0], repl[1])
        return title

#=============================================================================================== fonctions ========================================================
def gestionUploadTorrentAlldeb(tabHash, tabTorrentNew, dictHash):
    ok, ko = 0, 0
    alldeb = Alldebrid(KEYALLDEB)
    for i in range(0, len(dictHash), 20):
        infoCash = alldeb.testCash(list(dictHash.keys())[i: i + 20])
        #{'status': 'success', 'data': {'magnets': [{'magnet': '7DD73890CB7FFE90A7F28F311D90B4A9CD7EB1C4', 'hash': '7dd73890cb7ffe90a7f28f311d90b4a9cd7eb1c4', 'instant': False}
        for magnet in infoCash['data']["magnets"]:
            if magnet["instant"] == True:
                #notice("cash ok %s" %magnet["magnet"])
                ok += 1
                tabHash.append(dictHash[magnet["magnet"]][1])
                if dictHash[magnet["magnet"].upper()] in tabTorrentNew:
                    tabTorrentNew.remove(dictHash[magnet["magnet"].upper()][1])
            else:
                notice("out cash %s" %dictHash[magnet["magnet"]][1])
                ko += 1
    notice("AllDeb ok %d sur %d" %(ok, len(dictHash)))
    if ADDON.getSetting("uploadallded") != "false" and tabTorrentNew:
        tabTorrentNew = choixUpload(tabTorrentNew, "Alldeb")
        if tabTorrentNew:
            tabUp = [os.path.join(*v) for v in dictHash.values() if v[1] in tabTorrentNew]
            alldeb.uploadTorrent(tabUp)
    return tabHash

def gestionUploadTorrentRealdeb(tabHash, tabTorrentNew, dictHash):
    ok, ko = 0, 0
    rdb =  RealDebrid(KEYREALDEB)
    for i in range(0, len(dictHash), 20):
        infoCash = rdb.cacheHash(list(dictHash.keys())[i: i + 20])
        for k, v in infoCash.items():
            if v:
                ok += 1
                tabHash.append(dictHash[k.upper()][1])
                if dictHash[k.upper()][1] in tabTorrentNew:
                    tabTorrentNew.remove(dictHash[k.upper()][1])
            else:
                torrentAdd = os.path.join(*dictHash[k.upper()])
                if dictHash[k.upper()][1] in tabTorrentNew and ADDON.getSetting("uploadrealded") != "false":
                    notice("up torrent realdeb")
                    upTor = rdb.addTorrent(torrentAdd)
                    code = rdb.deleteTorrent(upTor["id"])
                notice("out cash %s" %dictHash[k.upper()][1])
                ko += 1
            #os.remove(os.path.join(*dictHash[k.upper()]))
    notice("RealDeb ok %d sur %d " %(ok, len(dictHash)))
    if ADDON.getSetting("uploadrealded") != "false" and tabTorrentNew:
        tabTorrentNew = choixUpload(tabTorrentNew, "Realdeb")
        if tabTorrentNew:
            tabUp = [os.path.join(*v) for v in dictHash.values() if v[1] in tabTorrentNew]
            for torrent in tabUp:
                upTor = rdb.addTorrent(torrent)
                rdb.startTorrent(upTor["id"])
    return tabHash

def choixUpload(tabTorrentNew, heberg):
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("Les torrents a Upload sur " + heberg, tabTorrentNew, preselect=[])
    tab = []
    if d:
        tab = [tabTorrentNew[x] for x in d]
    return tab

def majrssygg():
    bd = BDygg(BDYGG)
    listRSS = bd.getRss()
    tabTorrentNew = []
    listeRep = list(set([x[0] for x in listRSS]))
    tort = Torrent()
    dictRecup = {}
    for rep, url in listRSS[:]:
        #notice(url)
        _, nb = tort.recupTorrentsRss(url, rep, CHEMIN)
        if rep not in dictRecup.keys():
            dictRecup[rep] = nb
        else:
            dictRecup[rep] += nb
    dictHash = {}
    for rep in listeRep:
        for torrent in [x for x in os.listdir(os.path.join(CHEMIN, rep)) if x[-8:] == ".torrent"]:
            try:
                if not bd.getTorrent(torrent):
                    tabTorrentNew.append(torrent)
                title, infoHash, magnetFull = tort.make_magnet_from_file(os.path.join(CHEMIN, rep, torrent))
                bd.insertTorrent(title, infoHash, rep, magnetFull, torrent)
                shutil.move(os.path.join(CHEMIN, rep, torrent), os.path.join(CHEMIN, rep, "fait"))
                dictHash[infoHash] = (os.path.join(CHEMIN, rep, 'fait'), torrent)

            except Exception as e:
                notice(e)
                notice(torrent)
                os.remove(os.path.join(CHEMIN, rep, torrent))

    #verif cash
    tabHash = []
    if KEYALLDEB:
        tabHash = gestionUploadTorrentAlldeb(tabHash, tabTorrentNew, dictHash)

    if KEYREALDEB:
        tabHash = gestionUploadTorrentRealdeb(tabHash, tabTorrentNew, dictHash)
    notice("TOTAL ok %d sur %d" %(len(list(set(tabHash))), len(dictHash)))

    showInfoNotification("Torrent: %s" %(" - ").join(["%s (%d)"%(k, v) for k, v in dictRecup.items()]))
    if ADDON.getSetting("rskin") != "false":
        xbmc.executebuiltin('ReloadSkin')
    return True

def testThread():
    a = 0
    tActif = True
    while tActif:
        tActif = False
        for t in threading.enumerate():
            if "tet" == t.getName():
                tActif = True
        time.sleep(0.1)
        a += 1
        if a > 150:
            break
    return True

def affTorrent(typM, medias, params=""):
    typMedia = params["typm"]
    #notice(params)
    if typMedia in ["movie", "films", "anime", "docu"]:
        typMedia = "movie"
    else:
        typMedia = "tvshow"
    xbmcplugin.setPluginCategory(HANDLE, typM)
    xbmcplugin.setContent(HANDLE, 'movies')
    i = -1
    for i, media in enumerate(medias):
        try:
            media = Media(typM, *media[:-1])
        except:
            media = Media(typM, *media)
        delF = "ko"
        ok = addDirectoryTorrent("%s" %(media.title), isFolder=False, parameters={"action": "playTorrent", "lien": media.link, "u2p": media.numId, "delF": delF, "typm": typMedia}, media=media)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    if i > -1:
        if i >= (NBMEDIA - 1):
            addDirNext(params)
    xbmcplugin.endOfDirectory(handle=HANDLE, succeeded=True, cacheToDisc=True)

def addDirectoryTorrent(name, isFolder=True, parameters={}, media="" ):
    ''' Add a list item to the XBMC UI.'''
    li = xbmcgui.ListItem(label=name)
    updateInfoTagVideo2(li, media)

    if media.poster[-4:] == ".jpg":
        li.setArt({'icon': media.backdrop,
            'thumb': media.poster,
            'poster': media.poster,
            'fanart': media.backdrop})
    else:
        li.setArt({'icon': media.backdrop,
            'thumb': media.backdrop,
            'poster': media.backdrop,
            'fanart': media.backdrop})
    if media.clearlogo :
        li.setArt({'clearlogo': media.clearlogo})
    if media.clearart :
        li.setArt({'clearart': media.clearart})

    commands = []
    #if parameters["typm"] == "movie" and  media.numId:
    release = media.overview.split("\n")[0].replace("Release: ", "").replace(" ", ".")
    commands.append(('[COLOR yellow]Ajouter au contenu HK3[/COLOR]', 'RunPlugin(plugin://plugin.video.sendtokodiU2P/?action=addcontenu&lien=%s&typm=%s&u2p=%s&release=%s)' %(media.link, parameters["typm"], media.numId, release)))
    if commands:
        li.addContextMenuItems(commands)

    li.setProperty('IsPlayable', 'true')
    url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=isFolder)

def addDirNext(params):
    isFolder = True
    li = xbmcgui.ListItem(label="[COLOR red]Page Suivante[/COLOR]")
    updateEmptyInfoTag(li)
    li.setArt({
              'thumb': 'special://home/addons/plugin.video.sendtokodiU2P/resources/png/next.png',
              'icon': ADDON.getAddonInfo('icon'),
              'fanart': ADDON.getAddonInfo('fanart'),
              })
    try:
        params["offset"] = str(int(params["offset"]) + NBMEDIA)
    except: pass
    url = sys.argv[0] + '?' + urlencode(params)
    return xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=isFolder)

def importRss():
    bd = BDygg(BDYGG)
    rentryRSS = ADDON.getSetting("rss")
    tx = getBdRentry(rentryRSS)
    tabRSS = [(x.split("==")[0].strip(), x.split("==")[1].strip()) for x in tx.splitlines() if x and x[0] != "#" and "==" in x]
    bd.delRss()
    bd.insertRss(tabRSS)
    showInfoNotification("Import Ok!!")


def verifVu(vus, release, numId):
    try:
        renam = RenameMedia()
        title, saison, episode, year = renam.extractInfo(release, typM="tvshow")
        saison = int(episode.split("E")[0][1:])
        episode = int(episode.split("E")[1])
        numEpisode = "{}-{}-{}".format(numId.strip(), saison, episode)
        #notice("{} - {}".format(numEpisode, str(vus)))
        if numEpisode in vus:
            color = "green"
        else:
            color = "red"
    except: color = "white"
    return color

def cashAlldeb(params):
    notice("verif cash alldeb")
    tabLinks = []
    alldeb = Alldebrid(KEYALLDEB)
    #upload and debrid
    infoHash =  params["lien"]
    #magnet = 'magnet:?xt=urn:btih:%s&dn=%s' %(infoHash, title)
    magnet = 'magnet:?xt=urn:btih:%s' %(infoHash)
    dictInfos = alldeb.uploadMagnet(magnet)
    #notice(dictInfos)
    #{'status': 'success', 'data': {'magnets': [{'magnet': 'magnet:?xt=urn:btih:4F5AAB48CDF93FA94187F21A3E339E987063F747', 'hash': '4f5aab48cdf93fa94187f21a3e339e987063f747', 'name': 'Yannick.2023.FRENCH.WEBRip.x264.AC3-MULTiViSiON.mkv', 'filename_original': '', 'size': 744985901, 'ready': True, 'id': 213435767}]}}
    tabLinks = []
    if dictInfos["status"] == 'success':
        if dictInfos["data"]["magnets"]:
            for magnet in dictInfos["data"]["magnets"]:
                if "error" not in magnet.keys() and magnet["ready"]:
                    dictLinks = alldeb.extractMagnetsId(magnet["id"])
                    if dictLinks["status"] == 'success':
                        if dictLinks["data"]["magnets"]:
                            for link in dictLinks["data"]["magnets"]["links"]:
                                tabLinks.append((link["filename"], link["size"], link["link"]))

    """
    tcash = alldeb.testCash(infoHash)
    #notice(tcash)
    if infoHash in alldeb.extractEnCours:
        showInfoNotification("upload en Alldeb cours")

    else:
        #{'status': 'success', 'data': {'magnets': [{'magnet': '4F5AAB48CDF93FA94187F21A3E339E987063F747', 'hash': '4f5aab48cdf93fa94187f21a3e339e987063f747', 'instant': True, 'files': [{'n': 'Yannick.2023.FRENCH.WEBRip.x264.AC3-MULTiViSiON.mkv', 's': 744985901}]}]}}
        if tcash["status"] == "success" and tcash["data"]["magnets"][0]["instant"] == True:
            dictInfos = alldeb.uploadMagnet(magnet)
            #notice(dictInfos)
            #{'status': 'success', 'data': {'magnets': [{'magnet': 'magnet:?xt=urn:btih:4F5AAB48CDF93FA94187F21A3E339E987063F747', 'hash': '4f5aab48cdf93fa94187f21a3e339e987063f747', 'name': 'Yannick.2023.FRENCH.WEBRip.x264.AC3-MULTiViSiON.mkv', 'filename_original': '', 'size': 744985901, 'ready': True, 'id': 213435767}]}}
            tabLinks = []
            if dictInfos["status"] == 'success':
                if dictInfos["data"]["magnets"]:
                    for magnet in dictInfos["data"]["magnets"]:
                        if "error" not in magnet.keys() and magnet["ready"]:
                            dictLinks = alldeb.extractMagnetsId(magnet["id"])
                            if dictLinks["status"] == 'success':
                                if dictLinks["data"]["magnets"]:
                                    for link in dictLinks["data"]["magnets"]["links"]:
                                        tabLinks.append((link["filename"], link["size"], link["link"]))
    """
    return tabLinks

def cashRealdeb(params):
    notice("verif cash realdeb")
    tabLinks = []
    if "typm" in params.keys():
        typM = "tvshow"
    else:
        typM = "movie"
    hsh =  params["lien"]
    magnet = 'magnet:?xt=urn:btih:%s' %(hsh)
    rdb =  RealDebrid(KEYREALDEB)
    torrents = rdb.getTorrents()
    torrents = {x["hash"]: (x["links"], x["filename"], x["bytes"], x["id"], x['status']) for x in torrents}
    #notice(torrents)
    #return
    lT = [v for x, v in torrents.items() if hsh.upper() in x.upper()]
    #notice(lT)
    if lT:
        if lT[0][4] == 'downloaded':
            idfile = lT[0][3]
            notice("in compte realdeb")
            linksTorrent = rdb.torrentInfos(idfile)#["links"]
            files = linksTorrent["files"]
            links = linksTorrent["links"]
            if links:
                for i, file in enumerate(files):
                    #{'id': 9, 'path': '/La Créature de Kyŏngsŏng S01E09 - Atrocité.mkv', 'bytes': 1543846851, 'selected': 1}
                    try:
                        tabLinks.append((file["path"][1:], file["bytes"], links[i]))
                    except: pass
        else:
            showInfoNotification("upload RealDeb en cours")

    else:
        infoCash = rdb.cacheHash(hsh)
        #notice(infoCash)
        if infoCash[hsh.lower()]:
            notice("in cash realdeb")
            try:
                nums = rdb.getFiles(infoCash)
            except:
                nums = "all"
            if not nums:
                nums = "all"
            infos = rdb.addMagnet(hsh)
            code = rdb.startTorrent(infos["id"], nums)
            linksTorrent = rdb.torrentInfos(infos["id"])#["links"]
            files = linksTorrent["files"]
            links = linksTorrent["links"]
            for i, file in enumerate(files):
                #{'id': 9, 'path': '/La Créature de Kyŏngsŏng S01E09 - Atrocité.mkv', 'bytes': 1543846851, 'selected': 1}
                try:
                    tabLinks.append((file["path"][1:], file["bytes"], links[i]))
                except: pass
        else:
            notice("insert magnet Full")
            bd = BDygg(BDYGG)
            magnet = bd.getMagnet(hsh.upper())
            notice(magnet)
            if magnet:
                infos = rdb.addMagnet(magnet)
                notice(infos)
                time.sleep(0.5)
                code = rdb.startTorrent(infos["id"], "all")
                if code != 204:
                    rdb.deleteTorrent(infos["id"])
                notice(code)

    return sorted(tabLinks)

def playTorrent(params):
    #https://www.limetorrents.lol/home
    #magnet:?xt=urn:btih:f4eda3f0f4f2158ee0be4cdc92b0af509ecc1987&dn=Le.Compte.De.Monte.Cristo.1954.BD.Remux.Restored.FR.x264.DTS-HD.2.0-Notag.mkv&tr=http%3A%2F%2Ftracker.loadpeers.org%3A8080%2Fliz780Oe1wVMOxoPG6T838T6pt6vMhYQ%2Fannounce
    #magnet:?xt=urn:btih:f4eda3f0f4f2158ee0be4cdc92b0af509ecc1987&dn=Le.Compte.De.Monte.Cristo.1954.BD.Remux.Restored.FR.x264.DTS-HD.2.0-Notag.mkv&tr=http%3A%2F%2Ftracker.loadpeers.org%3A8080%2Fliz780Oe1wVMOxoPG6T838T6pt6vMhYQ%2Fannounce
    #notice(params)
    if "typm" in params.keys():
        typM = params["typm"]
    else:
        typM = "movie"
    tabLinks = []
    #KEYALLDEB = ""
    if KEYALLDEB:
        tabLinks = cashAlldeb(params)
        if tabLinks:
            debrid = "alldeb"
            notice("cash alldeb")

    if KEYREALDEB and not tabLinks:
        tabLinks = cashRealdeb(params)
        if tabLinks:
            debrid = "realdeb"
            notice("cash realdeb")

    if tabLinks:
        if typM == "tvshow":
            try:
                if ADDON.getSetting("bookonline") != "false":
                    vus = widget.responseSite("http://%s/requete.php?name=%s&type=getvu" %(ADDON.getSetting("bookonline_site"), ADDON.getSetting("bookonline_name")))
                else:
                    vus =  widget.getVu("tvshow")
            except:
                vus = []
            vus = [x for x in vus if x.split("-")[0] == params["u2p"]]
            #notice(vus)
            #['62286-8-7']
        else:
            vus = []
        tabNomLien = [("[COLOR %s]#[/COLOR]%s - %0.2fGo" %(verifVu(vus, x[0], params["u2p"]), x[0], x[1] / 1000000000.0), x[2]) for x in tabLinks if x[0][-4:].upper() not in (".NFO", ".ZIP", ".RAR", ".JPG")]
        #notice(tabNomLien)
        dialog = xbmcgui.Dialog()
        selected = dialog.select("Choix lien", [x[0] for x in tabNomLien], 0, 0)
        if selected != -1:
            lien = tabNomLien[selected][1]
            if debrid == "alldeb":
                alldeb = Alldebrid(KEYALLDEB)
                url, err = alldeb.linkDownload(lien)
            else:
                rdb =  RealDebrid(KEYREALDEB)
                url, err = rdb.linkDownload(lien)
            if url:
                release = unquote(url.split("/")[-1])
                renam = RenameMedia()
                title, saison, episode, year = renam.extractInfo(release, typM="tvshow")
                notice("%s %s %s %s %s" %(title, saison, episode, year, typM))
                if typM == "tvshow":
                    param = {"u2p": params["u2p"], 'action': "playHK", 'lien': url, 'episode': int(episode.split("E")[1]), "saison": saison, "typMedia": "episode", "torrent": 1}
                else:
                    param = {"u2p": params["u2p"], 'action': "playHK", 'lien': url, "typMedia": "movie", "torrent": 1}

                test = 1
                if test:
                    player.playMediaHK(param)
                    return
                else:

                    param = ["%s=%s" %(k, v) for k, v in param.items()]
                    param = "&".join(param)
                    #notice(param)
                    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.sendtokodiU2P/?%s)" %param)
                    """
                    result = {"url": url, "title": release}
                    if result and "url" in result.keys():
                        listIt = createListItemFromVideo(result)
                        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=listIt)
                    """
            else:
                showInfoNotification("Error %s" %err)
        else:
            return
    else:
        #alldeb.uploadMagnet(magnet)
        showInfoNotification("Pas dispo, essai plus tard")
        return


def rssygg(params):
    renam = RenameMedia()
    masqueF = r'(?P<titre>.*)(\(?)(?P<year>19\d\d|20\d\d)'
    typM = params["typm"]
    offset = params["offset"]
    bd = BDygg(BDYGG)
    tabFiles = bd.recupListe(typM, NBMEDIA, offset)
    mDB = TMDB(KEYTMDB)
    for i, (nom, filecode) in enumerate(tabFiles):
        #[ Torrent911.pw ]
        masqueTorrent911 = r"^\[.*\]"
        r = re.search(masqueTorrent911, nom)
        if r:
            nom = nom[r.end():]
        release = nom.replace(".", " ")
        if typM in ["films", "anime", "docu"]:
            name = nom.replace(":", ".").replace(" ", ".").replace(";", ".").replace("_", ".")
            name = re.sub(r"\.{2,}", ".", name)
            r = re.search(masqueF, name)
            if r:
                year = int(r.group("year"))
                rechT = r.group("titre")
            else:
                year = 0
                rechT = name
            threading.Thread(name="tet", target=mDB.searchMovie, args=(rechT, filecode, i, year, release)).start()
        else:
            title, saison, episode, year = renam.extractInfo(nom, typM="tvshow")
            threading.Thread(name="tet", target=mDB.searchEpisode, args=(title, saison, episode, filecode, i, int(year), release, )).start()

    testThread()
    medias = mDB.extractListe
    #for media in medias:
    #    notice(media)
    affTorrent("movie", [x[1:]  for x in medias], params)



if __name__ == '__main__':
    pass
